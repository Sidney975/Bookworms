using Bookworms.Models;
using Bookworms.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Bookworms.Pages
{
    public class ChangePasswordModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public ChangePasswordModel(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [BindProperty]
        public ChangePassword Input { get; set; }

        public void OnGet() { }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound("User not found.");
                //return RedirectToPage("Login");
            }

			// Define minimum password age (e.g., 1 day)
			TimeSpan minPasswordAge = TimeSpan.FromDays(1);
			if (DateTime.UtcNow - user.LastPasswordChangeDate < minPasswordAge)
			{
				ModelState.AddModelError(string.Empty, $"You can change your password only once every {minPasswordAge.TotalDays} days.");
				return Page();
			}

			var changePasswordResult = await _userManager.ChangePasswordAsync(user, Input.CurrentPassword, Input.NewPassword);
            if (!changePasswordResult.Succeeded)
            {
                foreach (var error in changePasswordResult.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
                return Page();
            }

			user.LastPasswordChangeDate = DateTime.UtcNow;
			await _userManager.UpdateAsync(user);


			await _signInManager.RefreshSignInAsync(user);
            return RedirectToPage("Index");
        }
    }
}
