using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Bookworms.Pages.errors
{
    public class _403Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
