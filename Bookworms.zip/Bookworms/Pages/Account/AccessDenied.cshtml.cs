using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Bookworms.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
